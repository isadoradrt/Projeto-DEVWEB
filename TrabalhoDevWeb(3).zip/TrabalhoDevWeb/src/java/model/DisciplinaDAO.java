package model;

import entidade.Disciplina;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;

public class DisciplinaDAO implements Dao<Disciplina> {

    @Override
    public void insert(Disciplina disciplina) {
        Conexao conexao = new Conexao();
        try {
            String sqlInsert = "INSERT INTO disciplina (nome, requisito, ementa, carga_horaria) VALUES (?, ?, ?, ?)";
            PreparedStatement stmt = conexao.getConexao().prepareStatement(sqlInsert);
            stmt.setString(1, disciplina.getNome());
            stmt.setString(2, disciplina.getRequisito());
            stmt.setString(3, disciplina.getEmenta());

            if (disciplina.getCargaHoraria() != null) {
                stmt.setInt(4, disciplina.getCargaHoraria());
            } else {
                stmt.setNull(4, Types.SMALLINT);
            }

            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao inserir disciplina: " + e.getMessage());
        } finally {
            conexao.closeConexao();
        }
    }

    public boolean existeNome(String nome, int id) {
        Conexao conexao = new Conexao();
        try {
            String sql = "SELECT COUNT(*) AS total FROM disciplina WHERE nome = ? AND id != ?";
            PreparedStatement stmt = conexao.getConexao().prepareStatement(sql);
            stmt.setString(1, nome);
            stmt.setInt(2, id);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return rs.getInt("total") > 0;
            }
            return false;
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao verificar nome da disciplina: " + e.getMessage());
        } finally {
            conexao.closeConexao();
        }
    }

    @Override
    public Disciplina get(int id) {
        Conexao conexao = new Conexao();
        try {
            Disciplina disciplina = null;
            String sql = "SELECT * FROM disciplina WHERE id = ?";
            PreparedStatement stmt = conexao.getConexao().prepareStatement(sql);
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                disciplina = new Disciplina();
                disciplina.setId(rs.getInt("id"));
                disciplina.setNome(rs.getString("nome"));
                disciplina.setRequisito(rs.getString("requisito"));
                disciplina.setEmenta(rs.getString("ementa"));

                int cargaHorariaValue = rs.getInt("carga_horaria");
                if (rs.wasNull()) {
                    disciplina.setCargaHoraria(null);
                } else {
                    disciplina.setCargaHoraria(cargaHorariaValue);
                }
            }

            return disciplina;
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao buscar disciplina: " + e.getMessage());
        } finally {
            conexao.closeConexao();
        }
    }

    @Override
    public void update(Disciplina disciplina) {
        Conexao conexao = new Conexao();
        try {
            String sqlUpdate = "UPDATE disciplina SET nome = ?, requisito = ?, ementa = ?, carga_horaria = ? WHERE id = ?";
            PreparedStatement stmt = conexao.getConexao().prepareStatement(sqlUpdate);
            stmt.setString(1, disciplina.getNome());
            stmt.setString(2, disciplina.getRequisito());
            stmt.setString(3, disciplina.getEmenta());

            if (disciplina.getCargaHoraria() != null) {
                stmt.setInt(4, disciplina.getCargaHoraria());
            } else {
                stmt.setNull(4, Types.SMALLINT);
            }

            stmt.setInt(5, disciplina.getId());

            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao alterar disciplina: " + e.getMessage());
        } finally {
            conexao.closeConexao();
        }
    }

    @Override
    public void delete(int id) {
        Conexao conexao = new Conexao();
        try {
            String sqlDelete = "DELETE FROM disciplina WHERE id = ?";
            PreparedStatement stmt = conexao.getConexao().prepareStatement(sqlDelete);
            stmt.setInt(1, id);
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao excluir disciplina: " + e.getMessage());
        } finally {
            conexao.closeConexao();
        }
    }

    @Override
    public ArrayList<Disciplina> getAll() {
        ArrayList<Disciplina> lista = new ArrayList<>();
        Conexao conexao = new Conexao();
        try {
            String sql = "SELECT * FROM disciplina ORDER BY id";
            PreparedStatement stmt = conexao.getConexao().prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Disciplina disciplina = new Disciplina();
                disciplina.setId(rs.getInt("id"));
                disciplina.setNome(rs.getString("nome"));
                disciplina.setRequisito(rs.getString("requisito"));
                disciplina.setEmenta(rs.getString("ementa"));

                int cargaHorariaValue = rs.getInt("carga_horaria");
                if (rs.wasNull()) {
                    disciplina.setCargaHoraria(null);
                } else {
                    disciplina.setCargaHoraria(cargaHorariaValue);
                }

                lista.add(disciplina);
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao listar disciplinas: " + e.getMessage());
        } finally {
            conexao.closeConexao();
        }
        return lista;
    }
}
