package model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import entidade.Professor;

public class ProfessorDAO implements Dao<Professor> {

    @Override
    public Professor get(int id) {
        Conexao conexao = new Conexao();
        try {
            Professor professor = new Professor();
            String sql = "SELECT * FROM professores WHERE id = ?";
            PreparedStatement stmt = conexao.getConexao().prepareStatement(sql);
            stmt.setInt(1, id);
            ResultSet resultado = stmt.executeQuery();
            if (resultado != null && resultado.next()) {
                professor.setId(resultado.getInt("id"));
                professor.setNome(resultado.getString("nome"));
                professor.setEmail(resultado.getString("email"));
                professor.setCpf(resultado.getString("cpf"));
                professor.setSenha(resultado.getString("senha"));
            }
            return professor;
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao buscar professor: " + e.getMessage());
        } finally {
            conexao.closeConexao();
        }
    }

    @Override
    public ArrayList<Professor> getAll() {
        ArrayList<Professor> meusProfessores = new ArrayList<>();
        Conexao conexao = new Conexao();
        try {
            String selectSQL = "SELECT * FROM professores ORDER BY id";
            PreparedStatement stmt = conexao.getConexao().prepareStatement(selectSQL);
            ResultSet resultado = stmt.executeQuery();
            while (resultado != null && resultado.next()) {
                Professor professor = new Professor();
                professor.setId(resultado.getInt("id"));
                professor.setNome(resultado.getString("nome"));
                professor.setEmail(resultado.getString("email"));
                professor.setCpf(resultado.getString("cpf"));
                professor.setSenha(resultado.getString("senha"));
                meusProfessores.add(professor);
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao listar professores: " + e.getMessage());
        } finally {
            conexao.closeConexao();
        }
        return meusProfessores;
    }

    @Override
    public void insert(Professor professor) {
        Conexao conexao = new Conexao();
        try {
            String sqlInsert = "INSERT INTO professores (nome, email, cpf, senha) VALUES (?, ?, ?, ?)";
            PreparedStatement stmt = conexao.getConexao().prepareStatement(sqlInsert);
            stmt.setString(1, professor.getNome());
            stmt.setString(2, professor.getEmail());
            stmt.setString(3, professor.getCpf());
            stmt.setString(4, professor.getSenha());
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao inserir professor: " + e.getMessage());
        } finally {
            conexao.closeConexao();
        }
    }

    @Override
    public void update(Professor professor) {
        Conexao conexao = new Conexao();
        try {
            String sql = "UPDATE professores SET nome = ?, email = ?, cpf = ?, senha = ? WHERE id = ?";
            PreparedStatement stmt = conexao.getConexao().prepareStatement(sql);
            stmt.setString(1, professor.getNome());
            stmt.setString(2, professor.getEmail());
            stmt.setString(3, professor.getCpf());
            stmt.setString(4, professor.getSenha());
            stmt.setInt(5, professor.getId());
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao atualizar professor: " + e.getMessage());
        } finally {
            conexao.closeConexao();
        }
    }

    @Override
    public void delete(int id) {
        Conexao conexao = new Conexao();
        try {
            String sqlDelete = "DELETE FROM professores WHERE id = ?";
            PreparedStatement stmt = conexao.getConexao().prepareStatement(sqlDelete);
            stmt.setInt(1, id);
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao excluir professor: " + e.getMessage());
        } finally {
            conexao.closeConexao();
        }
    }

    public boolean existeEmailOuCpf(String email, String cpf, int id) throws Exception {
        Conexao conexao = new Conexao();
        try {
            String sql
                    = "SELECT COUNT(*) AS total "
                    + "FROM ( "
                    + "    SELECT email, cpf FROM professores WHERE (email = ? OR cpf = ?) AND id != ? "
                    + "    UNION ALL "
                    + "    SELECT email, cpf FROM alunos WHERE (email = ? OR cpf = ?) "
                    + "    UNION ALL "
                    + "    SELECT cpf, NULL AS email FROM administrador WHERE cpf = ? "
                    + ") AS verificador";
            PreparedStatement stmt = conexao.getConexao().prepareStatement(sql);

            stmt.setString(1, email);
            stmt.setString(2, cpf);
            stmt.setInt(3, id);
            stmt.setString(4, email);
            stmt.setString(5, cpf);
            stmt.setString(6, cpf);

            ResultSet rs = stmt.executeQuery();

            return rs.next() && rs.getInt("total") > 0;
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao verificar email ou CPF: " + e.getMessage());
        } finally {
            conexao.closeConexao();
        }
    }

    public Professor logar(Professor professor) throws Exception {
        Conexao conexao = new Conexao();
        try {
            String sql = "SELECT * FROM professores WHERE cpf = ? AND senha = ? LIMIT 1";
            PreparedStatement stmt = conexao.getConexao().prepareStatement(sql);
            stmt.setString(1, professor.getCpf());
            stmt.setString(2, professor.getSenha());
            ResultSet resultado = stmt.executeQuery();
            Professor professorObtido = new Professor();
            if (resultado != null && resultado.next()) {
                professorObtido.setId(resultado.getInt("id"));
                professorObtido.setNome(resultado.getString("nome"));
                professorObtido.setEmail(resultado.getString("email"));
                professorObtido.setCpf(resultado.getString("cpf"));
                professorObtido.setSenha(resultado.getString("senha"));
            }
            return professorObtido;
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao logar professor: " + e.getMessage());
        } finally {
            conexao.closeConexao();
        }
    }
}
