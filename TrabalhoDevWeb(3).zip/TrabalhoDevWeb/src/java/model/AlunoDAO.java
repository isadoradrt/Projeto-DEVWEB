package model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import entidade.Aluno;

public class AlunoDAO implements Dao<Aluno> {

    @Override
    public void insert(Aluno aluno) {
        Conexao conexao = new Conexao();
        try {
            String sql = "INSERT INTO alunos (nome, email, celular, cpf, senha, endereco, cidade, bairro, cep) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement stmt = conexao.getConexao().prepareStatement(sql);
            stmt.setString(1, aluno.getNome());
            stmt.setString(2, aluno.getEmail());
            stmt.setString(3, aluno.getCelular());
            stmt.setString(4, aluno.getCpf());
            stmt.setString(5, aluno.getSenha());
            stmt.setString(6, aluno.getEndereco());
            stmt.setString(7, aluno.getCidade());
            stmt.setString(8, aluno.getBairro());
            stmt.setString(9, aluno.getCep());
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao inserir aluno: " + e.getMessage());
        } finally {
            conexao.closeConexao();
        }
    }

    @Override
    public Aluno get(int id) {
        Conexao conexao = new Conexao();
        try {
            String sql = "SELECT * FROM alunos WHERE id = ?";
            PreparedStatement stmt = conexao.getConexao().prepareStatement(sql);
            stmt.setInt(1, id);
            ResultSet resultado = stmt.executeQuery();

            if (resultado.next()) {
                Aluno aluno = new Aluno();
                aluno.setId(resultado.getInt("id"));
                aluno.setNome(resultado.getString("nome"));
                aluno.setEmail(resultado.getString("email"));
                aluno.setCelular(resultado.getString("celular"));
                aluno.setCpf(resultado.getString("cpf"));
                aluno.setSenha(resultado.getString("senha"));
                aluno.setEndereco(resultado.getString("endereco"));
                aluno.setCidade(resultado.getString("cidade"));
                aluno.setBairro(resultado.getString("bairro"));
                aluno.setCep(resultado.getString("cep"));
                return aluno;
            }
            return null;
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao buscar aluno: " + e.getMessage());
        } finally {
            conexao.closeConexao();
        }
    }

    @Override
    public ArrayList<Aluno> getAll() {
        ArrayList<Aluno> alunos = new ArrayList<>();
        Conexao conexao = new Conexao();
        try {
            String sql = "SELECT * FROM alunos ORDER BY id";
            PreparedStatement stmt = conexao.getConexao().prepareStatement(sql);
            ResultSet resultado = stmt.executeQuery();

            while (resultado.next()) {
                Aluno aluno = new Aluno();
                aluno.setId(resultado.getInt("id"));
                aluno.setNome(resultado.getString("nome"));
                aluno.setEmail(resultado.getString("email"));
                aluno.setCelular(resultado.getString("celular"));
                aluno.setCpf(resultado.getString("cpf"));
                aluno.setSenha(resultado.getString("senha"));
                aluno.setEndereco(resultado.getString("endereco"));
                aluno.setCidade(resultado.getString("cidade"));
                aluno.setBairro(resultado.getString("bairro"));
                aluno.setCep(resultado.getString("cep"));
                alunos.add(aluno);
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao listar alunos: " + e.getMessage());
        } finally {
            conexao.closeConexao();
        }
        return alunos;
    }

    @Override
    public void update(Aluno aluno) {
        Conexao conexao = new Conexao();
        try {
            String sql = "UPDATE alunos SET nome = ?, email = ?, celular = ?, cpf = ?, senha = ?, endereco = ?, cidade = ?, bairro = ?, cep = ? WHERE id = ?";
            PreparedStatement stmt = conexao.getConexao().prepareStatement(sql);
            stmt.setString(1, aluno.getNome());
            stmt.setString(2, aluno.getEmail());
            stmt.setString(3, aluno.getCelular());
            stmt.setString(4, aluno.getCpf());
            stmt.setString(5, aluno.getSenha());
            stmt.setString(6, aluno.getEndereco());
            stmt.setString(7, aluno.getCidade());
            stmt.setString(8, aluno.getBairro());
            stmt.setString(9, aluno.getCep());
            stmt.setInt(10, aluno.getId());
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao atualizar aluno: " + e.getMessage());
        } finally {
            conexao.closeConexao();
        }
    }

    @Override
    public void delete(int id) {
        Conexao conexao = new Conexao();
        try {
            String sql = "DELETE FROM alunos WHERE id = ?";
            PreparedStatement stmt = conexao.getConexao().prepareStatement(sql);
            stmt.setInt(1, id);
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao excluir aluno: " + e.getMessage());
        } finally {
            conexao.closeConexao();
        }
    }

    public boolean existeEmailOuCpf(String email, String cpf, int id) {
        Conexao conexao = new Conexao();
        try {
            String sql
                    = "SELECT COUNT(*) AS total "
                    + "FROM ( "
                    + "    SELECT email, cpf FROM alunos WHERE (email = ? OR cpf = ?) AND id != ? "
                    + "    UNION ALL "
                    + "    SELECT email, cpf FROM professores WHERE (email = ? OR cpf = ?) "
                    + "    UNION ALL "
                    + "    SELECT NULL AS email, cpf FROM administrador WHERE cpf = ? "
                    + ") AS verificador";
            PreparedStatement stmt = conexao.getConexao().prepareStatement(sql);
            stmt.setString(1, email);
            stmt.setString(2, cpf);
            stmt.setInt(3, id);
            stmt.setString(4, email);
            stmt.setString(5, cpf);
            stmt.setString(6, cpf);
            ResultSet rs = stmt.executeQuery();

            return rs.next() && rs.getInt("total") > 0;
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao verificar email ou CPF: " + e.getMessage());
        } finally {
            conexao.closeConexao();
        }
    }

    public Aluno logar(Aluno aluno) {
        Conexao conexao = new Conexao();
        try {
            String sql = "SELECT * FROM alunos WHERE cpf = ? AND senha = ? LIMIT 1";
            PreparedStatement stmt = conexao.getConexao().prepareStatement(sql);
            stmt.setString(1, aluno.getCpf());
            stmt.setString(2, aluno.getSenha());
            ResultSet rs = stmt.executeQuery();
            Aluno alunoObtido = new Aluno();
            if (rs.next()) {
                alunoObtido.setId(rs.getInt("id"));
                alunoObtido.setNome(rs.getString("nome"));
                alunoObtido.setEmail(rs.getString("email"));
                alunoObtido.setCelular(rs.getString("celular"));
                alunoObtido.setCpf(rs.getString("cpf"));
                alunoObtido.setSenha(rs.getString("senha"));
                alunoObtido.setEndereco(rs.getString("endereco"));
                alunoObtido.setCidade(rs.getString("cidade"));
                alunoObtido.setBairro(rs.getString("bairro"));
                alunoObtido.setCep(rs.getString("cep"));
                return alunoObtido;
            }
            return null;
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao realizar login: " + e.getMessage());
        } finally {
            conexao.closeConexao();
        }
    }
}
