package model;

import entidade.Relatorio;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class RelatorioDAO {

    public ArrayList<Relatorio> gerarRelatorioTurmas() throws Exception {
        ArrayList<Relatorio> relatorios = new ArrayList<>();
        Conexao conexao = new Conexao();
        try {
            String sql = "SELECT t.codigo_turma, d.nome AS disciplina_nome, a.nome AS aluno_nome, t.nota "
                    + "FROM turmas t "
                    + "INNER JOIN disciplina d ON t.disciplina_id = d.id "
                    + "INNER JOIN alunos a ON t.aluno_id = a.id "
                    + "ORDER BY t.codigo_turma, d.nome, a.nome";

            PreparedStatement stmt = conexao.getConexao().prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Relatorio relatorio = new Relatorio();
                relatorio.setCodigoTurma(rs.getString("codigo_turma"));
                relatorio.setDisciplinaNome(rs.getString("disciplina_nome"));
                relatorio.setAlunoNome(rs.getString("aluno_nome"));
                relatorio.setNota(rs.getDouble("nota"));
                relatorios.add(relatorio);
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao gerar relatório das turmas: " + e.getMessage());
        } finally {
            conexao.closeConexao();
        }
        return relatorios;
    }

    public ArrayList<Relatorio> gerarRelatorioPorTurma(String codigoTurma) throws Exception {
        ArrayList<Relatorio> relatorios = new ArrayList<>();
        Conexao conexao = new Conexao();
        try {
            String sql = "SELECT t.codigo_turma, d.nome AS disciplina_nome, a.nome AS aluno_nome, t.nota "
                    + "FROM turmas t "
                    + "INNER JOIN disciplina d ON t.disciplina_id = d.id "
                    + "INNER JOIN alunos a ON t.aluno_id = a.id "
                    + "WHERE t.codigo_turma = ? "
                    + "ORDER BY d.nome, a.nome";

            PreparedStatement stmt = conexao.getConexao().prepareStatement(sql);
            stmt.setString(1, codigoTurma);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Relatorio relatorio = new Relatorio();
                relatorio.setCodigoTurma(rs.getString("codigo_turma"));
                relatorio.setDisciplinaNome(rs.getString("disciplina_nome"));
                relatorio.setAlunoNome(rs.getString("aluno_nome"));
                relatorio.setNota(rs.getDouble("nota"));
                relatorios.add(relatorio);
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao gerar relatório da turma específica: " + e.getMessage());
        } finally {
            conexao.closeConexao();
        }
        return relatorios;
    }

    public ArrayList<String> listarCodigosDeTurma() throws Exception {
        ArrayList<String> listaCodigos = new ArrayList<>();
        Conexao conexao = new Conexao();
        try {
            String sql = "SELECT DISTINCT codigo_turma FROM turmas ORDER BY codigo_turma";
            PreparedStatement stmt = conexao.getConexao().prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                listaCodigos.add(rs.getString("codigo_turma"));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao listar códigos de turma: " + e.getMessage());
        } finally {
            conexao.closeConexao();
        }
        return listaCodigos;
    }

}
