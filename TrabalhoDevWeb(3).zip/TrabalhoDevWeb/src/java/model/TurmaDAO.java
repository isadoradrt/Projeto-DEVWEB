package model;

import entidade.Turma;
import entidade.Disciplina;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class TurmaDAO {

    public void insert(Turma turma) throws Exception {
        Conexao conexao = new Conexao();
        try {
            String sqlInsert = "INSERT INTO turmas (professor_id, disciplina_id, aluno_id, codigo_turma, nota) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement stmt = conexao.getConexao().prepareStatement(sqlInsert);
            stmt.setInt(1, turma.getProfessorId());
            stmt.setInt(2, turma.getDisciplinaId());
            stmt.setInt(3, turma.getAlunoId());
            stmt.setString(4, turma.getCodigoTurma());
            stmt.setDouble(5, turma.getNota());

            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao inserir turma: " + e.getMessage());
        } finally {
            conexao.closeConexao();
        }
    }

    public void inserirEmLote(int professorId, int disciplinaId, String codigoTurma, String[] alunoIds, double notaInicial) throws Exception {
        Conexao conexao = new Conexao();
        try {
            String sqlInsert = "INSERT INTO turmas (professor_id, disciplina_id, aluno_id, codigo_turma, nota) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement stmt = conexao.getConexao().prepareStatement(sqlInsert);

            for (String alunoIdStr : alunoIds) {
                int alunoId = Integer.parseInt(alunoIdStr);
                stmt.setInt(1, professorId);
                stmt.setInt(2, disciplinaId);
                stmt.setInt(3, alunoId);
                stmt.setString(4, codigoTurma);
                stmt.setDouble(5, notaInicial);
                stmt.addBatch();
            }

            stmt.executeBatch();
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao inserir turmas em lote: " + e.getMessage());
        } finally {
            conexao.closeConexao();
        }
    }

    public boolean existeCodigoTurma(String codigoTurma, int professorId, int disciplinaId) throws Exception {
        Conexao conexao = new Conexao();
        try {
            String sql = "SELECT COUNT(*) AS total FROM turmas WHERE codigo_turma = ? AND professor_id = ? AND disciplina_id = ?";
            PreparedStatement stmt = conexao.getConexao().prepareStatement(sql);
            stmt.setString(1, codigoTurma);
            stmt.setInt(2, professorId);
            stmt.setInt(3, disciplinaId);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return rs.getInt("total") > 0;
            }
            return false;
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao verificar código da turma: " + e.getMessage());
        } finally {
            conexao.closeConexao();
        }
    }

    public ArrayList<Turma> listaTurmasConsolidadas() throws Exception {
        ArrayList<Turma> lista = new ArrayList<>();
        Conexao conexao = new Conexao();
        try {
            String sql = "SELECT t.codigo_turma, d.nome AS disciplina_nome, p.nome AS professor_nome "
                    + "FROM turmas t "
                    + "INNER JOIN disciplina d ON t.disciplina_id = d.id "
                    + "INNER JOIN professores p ON t.professor_id = p.id "
                    + "GROUP BY t.codigo_turma, d.nome, p.nome "
                    + "ORDER BY t.codigo_turma";

            PreparedStatement stmt = conexao.getConexao().prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Turma turma = new Turma();
                turma.setCodigoTurma(rs.getString("codigo_turma"));
                turma.setDisciplinaNome(rs.getString("disciplina_nome"));
                turma.setProfessorNome(rs.getString("professor_nome"));

                lista.add(turma);
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao listar turmas consolidadas: " + e.getMessage());
        } finally {
            conexao.closeConexao();
        }
        return lista;
    }

    public void update(Turma turma) throws Exception {
        Conexao conexao = new Conexao();
        try {
            String sqlUpdate = "UPDATE turmas SET professor_id = ?, disciplina_id = ?, aluno_id = ?, codigo_turma = ?, nota = ? WHERE id = ?";
            PreparedStatement stmt = conexao.getConexao().prepareStatement(sqlUpdate);
            stmt.setInt(1, turma.getProfessorId());
            stmt.setInt(2, turma.getDisciplinaId());
            stmt.setInt(3, turma.getAlunoId());
            stmt.setString(4, turma.getCodigoTurma());
            stmt.setDouble(5, turma.getNota());
            stmt.setInt(6, turma.getId());

            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao alterar turma: " + e.getMessage());
        } finally {
            conexao.closeConexao();
        }
    }

    public ArrayList<Turma> obterTurmaPorCodigo(String codigoTurma) throws Exception {
        Conexao conexao = new Conexao();
        ArrayList<Turma> lista = new ArrayList<>();
        try {
            String sql = "SELECT * FROM turmas WHERE codigo_turma = ?";
            PreparedStatement stmt = conexao.getConexao().prepareStatement(sql);
            stmt.setString(1, codigoTurma);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Turma turma = new Turma();
                turma.setId(rs.getInt("id"));
                turma.setProfessorId(rs.getInt("professor_id"));
                turma.setDisciplinaId(rs.getInt("disciplina_id"));
                turma.setAlunoId(rs.getInt("aluno_id"));
                turma.setCodigoTurma(rs.getString("codigo_turma"));
                turma.setNota(rs.getDouble("nota"));

                lista.add(turma);
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao obter turma por código: " + e.getMessage());
        } finally {
            conexao.closeConexao();
        }
        return lista;
    }

    public void excluirPorCodigo(String codigoTurma) throws Exception {
        Conexao conexao = new Conexao();
        try {
            String sqlDelete = "DELETE FROM turmas WHERE codigo_turma = ?";
            PreparedStatement stmt = conexao.getConexao().prepareStatement(sqlDelete);
            stmt.setString(1, codigoTurma);
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao excluir turma por código: " + e.getMessage());
        } finally {
            conexao.closeConexao();
        }
    }

    public ArrayList<Turma> listaDeTurmas() throws Exception {
        ArrayList<Turma> lista = new ArrayList<>();
        Conexao conexao = new Conexao();
        try {
            String sql = "SELECT * FROM turmas ORDER BY id";
            PreparedStatement stmt = conexao.getConexao().prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Turma turma = new Turma();
                turma.setId(rs.getInt("id"));
                turma.setProfessorId(rs.getInt("professor_id"));
                turma.setDisciplinaId(rs.getInt("disciplina_id"));
                turma.setAlunoId(rs.getInt("aluno_id"));
                turma.setCodigoTurma(rs.getString("codigo_turma"));
                turma.setNota(rs.getDouble("nota"));

                lista.add(turma);
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao listar turmas: " + e.getMessage());
        } finally {
            conexao.closeConexao();
        }
        return lista;
    }

    public boolean codigoTurmaJaExiste(String codigoTurma) throws Exception {
        Conexao conexao = new Conexao();
        try {
            String sql = "SELECT COUNT(*) AS total FROM turmas WHERE codigo_turma = ?";
            PreparedStatement stmt = conexao.getConexao().prepareStatement(sql);
            stmt.setString(1, codigoTurma);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return rs.getInt("total") > 0;
            }
            return false;
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao verificar se o código da turma já existe: " + e.getMessage());
        } finally {
            conexao.closeConexao();
        }
    }

    public ArrayList<Turma> listaTurmasComStatus() throws Exception {
        ArrayList<Turma> lista = new ArrayList<>();
        Conexao conexao = new Conexao();
        try {
            String sql = "SELECT t.codigo_turma, d.id AS disciplina_id, d.nome AS disciplina_nome, "
                    + "       d.requisito, d.ementa, d.carga_horaria, "
                    + "       p.nome AS professor_nome, "
                    + "       COUNT(t.aluno_id) AS num_alunos, "
                    + "       2 AS max_alunos " // Capacidade fixa de 2 alunos por turma
                    + "FROM turmas t "
                    + "INNER JOIN disciplina d ON t.disciplina_id = d.id "
                    + "INNER JOIN professores p ON t.professor_id = p.id "
                    + "GROUP BY t.codigo_turma, d.id, d.nome, d.requisito, d.ementa, d.carga_horaria, p.nome "
                    + "ORDER BY t.codigo_turma";

            PreparedStatement stmt = conexao.getConexao().prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Turma turma = new Turma();
                turma.setCodigoTurma(rs.getString("codigo_turma"));
                turma.setProfessorNome(rs.getString("professor_nome"));
                turma.setNumAlunos(rs.getInt("num_alunos")); // Número atual de alunos na turma
                turma.setMaxAlunos(rs.getInt("max_alunos")); // Capacidade máxima (fixa)
                turma.atualizarStatus(); // Atualiza o status da turma (Disponível ou Cheia)

                // Criar e popular o objeto Disciplina
                Disciplina disciplina = new Disciplina();
                disciplina.setId(rs.getInt("disciplina_id"));
                disciplina.setNome(rs.getString("disciplina_nome"));
                disciplina.setRequisito(rs.getString("requisito"));
                disciplina.setEmenta(rs.getString("ementa"));
                disciplina.setCargaHoraria(rs.getInt("carga_horaria"));

                // Associar a disciplina à turma
                turma.setDisciplina(disciplina);

                lista.add(turma);
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao listar turmas com status: " + e.getMessage());
        } finally {
            conexao.closeConexao();
        }
        return lista;
    }

    public boolean inscreverAluno(int alunoId, String codigoTurma) throws Exception {
        Conexao conexao = new Conexao();
        try {
            // Inserir o aluno na turma diretamente
            String inserirAlunoSQL = "INSERT INTO turmas (professor_id, disciplina_id, aluno_id, codigo_turma, nota) "
                    + "SELECT professor_id, disciplina_id, ?, codigo_turma, 0 "
                    + "FROM turmas WHERE codigo_turma = ? LIMIT 1";
            PreparedStatement inserirStmt = conexao.getConexao().prepareStatement(inserirAlunoSQL);
            inserirStmt.setInt(1, alunoId);
            inserirStmt.setString(2, codigoTurma);

            int rowsAffected = inserirStmt.executeUpdate();
            return rowsAffected > 0; // Retorna true se o aluno foi inscrito com sucesso
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao inscrever aluno na turma: " + e.getMessage(), e);
        } finally {
            conexao.closeConexao();
        }
    }

    public ArrayList<Turma> listarDisciplinasInscritas(int alunoId) throws Exception {
        ArrayList<Turma> lista = new ArrayList<>();
        Conexao conexao = new Conexao();
        try {
            String sql = "SELECT t.codigo_turma, d.nome AS disciplina_nome, t.nota "
                    + "FROM turmas t "
                    + "INNER JOIN disciplina d ON t.disciplina_id = d.id "
                    + "WHERE t.aluno_id = ? "
                    + "ORDER BY t.codigo_turma";

            PreparedStatement stmt = conexao.getConexao().prepareStatement(sql);
            stmt.setInt(1, alunoId); // Substitui o parâmetro pelo ID do aluno
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Turma turma = new Turma();
                turma.setCodigoTurma(rs.getString("codigo_turma"));
                turma.setDisciplinaNome(rs.getString("disciplina_nome"));
                turma.setNota(rs.getDouble("nota")); // Nota associada à inscrição do aluno

                lista.add(turma);
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao listar matérias inscritas: " + e.getMessage());
        } finally {
            conexao.closeConexao();
        }
        return lista;
    }

    public boolean excluirInscricao(int alunoId, String codigoTurma) throws Exception {
        Conexao conexao = new Conexao();
        boolean sucesso = false;
        try {
            String sql = "DELETE FROM turmas "
                    + "WHERE aluno_id = ? AND codigo_turma = ?";

            PreparedStatement stmt = conexao.getConexao().prepareStatement(sql);
            stmt.setInt(1, alunoId); // Substitui o parâmetro pelo ID do aluno
            stmt.setString(2, codigoTurma); // Substitui o parâmetro pelo código da turma

            int linhasAfetadas = stmt.executeUpdate();
            sucesso = (linhasAfetadas > 0); // Retorna true se alguma linha foi afetada
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao excluir inscrição do aluno na turma: " + e.getMessage());
        } finally {
            conexao.closeConexao();
        }
        return sucesso;
    }
    
    public ArrayList<Turma> listarNotasPorProfessor(int professorId) throws SQLException {
        Conexao conexao = new Conexao();
        ArrayList<Turma> turmas = new ArrayList<>();
        
        try {
            String sql = "SELECT p.nome AS professor_nome, d.nome AS disciplina_nome, t.codigo_turma, a.nome AS aluno_nome, t.nota " +
                     "FROM turmas t " +
                     "JOIN professores p ON t.professor_id = p.id " +
                     "JOIN disciplina d ON t.disciplina_id = d.id " +
                     "JOIN alunos a ON t.aluno_id = a.id " +
                     "WHERE t.professor_id = ?";

            PreparedStatement stmt = conexao.getConexao().prepareStatement(sql); 
            stmt.setInt(1, professorId); // Define o ID do professor
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                Turma turma = new Turma();
                turma.setProfessorNome(rs.getString("professor_nome"));
                turma.setDisciplinaNome(rs.getString("disciplina_nome"));
                turma.setCodigoTurma(rs.getString("codigo_turma"));
                turma.setAlunoNome(rs.getString("aluno_nome"));
                turma.setNota(rs.getDouble("nota"));
                turmas.add(turma);
                }
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao inscrever aluno na turma: " + e.getMessage(), e);
        } finally {
            conexao.closeConexao();
        }        
        return turmas;
    }
    
    public ArrayList<Turma> listarAlunosPorProfessor(int professorId) throws SQLException {
        Conexao conexao = new Conexao();
        ArrayList<Turma> turmas = new ArrayList<>();

        try {
            String sql = "SELECT t.id AS turma_id, p.nome AS professor_nome, d.nome AS disciplina_nome, " +
                         "t.codigo_turma, a.id AS aluno_id, a.nome AS aluno_nome, t.nota " +
                         "FROM turmas t " +
                         "JOIN professores p ON t.professor_id = p.id " +
                         "JOIN disciplina d ON t.disciplina_id = d.id " +
                         "JOIN alunos a ON t.aluno_id = a.id " +
                         "WHERE t.professor_id = ?";

            PreparedStatement stmt = conexao.getConexao().prepareStatement(sql);
            stmt.setInt(1, professorId);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Turma turma = new Turma();
                turma.setId(rs.getInt("turma_id"));
                turma.setProfessorNome(rs.getString("professor_nome"));
                turma.setDisciplinaNome(rs.getString("disciplina_nome"));
                turma.setCodigoTurma(rs.getString("codigo_turma"));
                turma.setAlunoId(rs.getInt("aluno_id"));
                turma.setAlunoNome(rs.getString("aluno_nome"));
                turma.setNota(rs.getDouble("nota"));
                turmas.add(turma);
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao listar alunos e notas: " + e.getMessage(), e);
        } finally {
            conexao.closeConexao();
        }        
        return turmas;
    }
    
    public boolean atualizarNota(String turmaId, int alunoId, double nota) throws SQLException {
        Conexao conexao = new Conexao();
        try {
            String sql = "UPDATE turmas SET nota = ? WHERE id = ? AND aluno_id = ?";
            PreparedStatement stmt = conexao.getConexao().prepareStatement(sql);
            stmt.setDouble(1, nota);
            stmt.setString(2, turmaId);
            stmt.setInt(3, alunoId);

            // Verifica quantas linhas foram afetadas
            int linhasAfetadas = stmt.executeUpdate();
            return linhasAfetadas > 0; // Retorna true se alguma linha foi atualizada
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao atualizar a nota do aluno: " + e.getMessage(), e);
        } finally {
            conexao.closeConexao();
        }
    }
        
}

