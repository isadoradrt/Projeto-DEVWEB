package model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import entidade.Administrador;

public class AdministradorDAO implements Dao<Administrador> {

    @Override
    public void insert(Administrador administrador) {
        Conexao conexao = new Conexao();
        try {
            String sql = "INSERT INTO Administrador (nome, cpf, endereco, senha, aprovado) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement stmt = conexao.getConexao().prepareStatement(sql);
            stmt.setString(1, administrador.getNome());
            stmt.setString(2, administrador.getCpf());
            stmt.setString(3, administrador.getEndereco());
            stmt.setString(4, administrador.getSenha());
            stmt.setString(5, administrador.getAprovado());
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao inserir administrador: " + e.getMessage());
        } finally {
            conexao.closeConexao();
        }
    }

    @Override
    public Administrador get(int id) {
        Conexao conexao = new Conexao();
        try {
            Administrador administrador = new Administrador();
            String sql = "SELECT * FROM Administrador WHERE ID = ?";
            PreparedStatement stmt = conexao.getConexao().prepareStatement(sql);
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                administrador.setId(rs.getInt("ID"));
                administrador.setNome(rs.getString("NOME"));
                administrador.setCpf(rs.getString("CPF"));
                administrador.setEndereco(rs.getString("ENDERECO"));
                administrador.setSenha(rs.getString("SENHA"));
                administrador.setAprovado(rs.getString("APROVADO"));
            }
            return administrador;
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao buscar administrador: " + e.getMessage());
        } finally {
            conexao.closeConexao();
        }
    }

    @Override
    public void update(Administrador administrador) {
        Conexao conexao = new Conexao();
        try {
            String sql = "UPDATE Administrador SET nome = ?, cpf = ?, endereco = ?, senha = ?, aprovado = ? WHERE ID = ?";
            PreparedStatement stmt = conexao.getConexao().prepareStatement(sql);
            stmt.setString(1, administrador.getNome());
            stmt.setString(2, administrador.getCpf());
            stmt.setString(3, administrador.getEndereco());
            stmt.setString(4, administrador.getSenha());
            stmt.setString(5, administrador.getAprovado());
            stmt.setInt(6, administrador.getId());
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao atualizar administrador: " + e.getMessage());
        } finally {
            conexao.closeConexao();
        }
    }

    @Override
    public void delete(int id) {
        Conexao conexao = new Conexao();
        try {
            String sql = "DELETE FROM Administrador WHERE ID = ?";
            PreparedStatement stmt = conexao.getConexao().prepareStatement(sql);
            stmt.setInt(1, id);
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao excluir administrador: " + e.getMessage());
        } finally {
            conexao.closeConexao();
        }
    }

    @Override
    public ArrayList<Administrador> getAll() {
        ArrayList<Administrador> administradores = new ArrayList<>();
        Conexao conexao = new Conexao();
        try {
            String sql = "SELECT * FROM Administrador ORDER BY nome";
            PreparedStatement stmt = conexao.getConexao().prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Administrador administrador = new Administrador();
                administrador.setId(rs.getInt("ID"));
                administrador.setNome(rs.getString("NOME"));
                administrador.setCpf(rs.getString("CPF"));
                administrador.setEndereco(rs.getString("ENDERECO"));
                administrador.setSenha(rs.getString("SENHA"));
                administrador.setAprovado(rs.getString("APROVADO"));
                administradores.add(administrador);
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao listar administradores: " + e.getMessage());
        } finally {
            conexao.closeConexao();
        }
        return administradores;
    }

    public Administrador logar(Administrador administrador) {
        Conexao conexao = new Conexao();
        try {
            String sql = "SELECT * FROM Administrador WHERE cpf = ? AND senha = ? LIMIT 1";
            PreparedStatement stmt = conexao.getConexao().prepareStatement(sql);
            stmt.setString(1, administrador.getCpf());
            stmt.setString(2, administrador.getSenha());
            ResultSet rs = stmt.executeQuery();
            Administrador administradorObtido = new Administrador();
            if (rs.next()) {
                administradorObtido.setId(rs.getInt("ID"));
                administradorObtido.setNome(rs.getString("NOME"));
                administradorObtido.setCpf(rs.getString("CPF"));
                administradorObtido.setEndereco(rs.getString("ENDERECO"));
                administradorObtido.setSenha(rs.getString("SENHA"));
                administradorObtido.setAprovado(rs.getString("APROVADO"));
            }
            return administradorObtido;
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao logar administrador: " + e.getMessage());
        } finally {
            conexao.closeConexao();
        }
    }

    public boolean existeCpf(String cpf, int id) {
        Conexao conexao = new Conexao();
        try {
            String sql
                    = "SELECT COUNT(*) AS total "
                    + "FROM ( "
                    + "    SELECT cpf FROM Administrador WHERE cpf = ? AND id != ? "
                    + "    UNION ALL "
                    + "    SELECT cpf FROM Alunos WHERE cpf = ? "
                    + "    UNION ALL "
                    + "    SELECT cpf FROM Professores WHERE cpf = ? "
                    + ") AS verificador";
            PreparedStatement stmt = conexao.getConexao().prepareStatement(sql);
            stmt.setString(1, cpf); // Administrador
            stmt.setInt(2, id);     // Excluindo o ID atual
            stmt.setString(3, cpf); // Alunos
            stmt.setString(4, cpf); // Professores
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return rs.getInt("total") > 0;
            }
            return false;
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao verificar CPF: " + e.getMessage());
        } finally {
            conexao.closeConexao();
        }
    }
}
