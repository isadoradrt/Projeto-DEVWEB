package controller;

import entidade.Turma;
import model.TurmaDAO;

import java.io.IOException;
import java.util.ArrayList;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "disciplinaController", urlPatterns = {"/disciplinaController"})
public class disciplinaController extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        TurmaDAO turmaDAO = new TurmaDAO();

        try {
            ArrayList<Turma> listaTurmas = turmaDAO.listaTurmasComStatus();
            request.setAttribute("listaTurmas", listaTurmas);

            RequestDispatcher rd = request.getRequestDispatcher("/views/public/mostrarDisciplinas.jsp");
            rd.forward(request, response);
        } catch (Exception e) {
            throw new ServletException("Erro ao listar turmas disponíveis: " + e.getMessage(), e);
        }
    }
}
