package controller.aluno;

import entidade.Turma;
import model.TurmaDAO;

import java.io.IOException;
import java.util.ArrayList;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(name = "alunoController", urlPatterns = {"/alunoController"})
public class alunoController extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        TurmaDAO turmaDAO = new TurmaDAO();

        String acao = request.getParameter("acao");
        if (acao == null) {
            acao = "ListarDisponiveis";
        }

        RequestDispatcher rd = null;

        switch (acao) {
            case "ListarDisponiveis":
                // Lista todas as turmas disponíveis para o aluno se inscrever
                try {
                    ArrayList<Turma> listaTurmas = turmaDAO.listaTurmasComStatus();
                    request.setAttribute("listaTurmas", listaTurmas);
                    rd = request.getRequestDispatcher("/views/aluno/disciplina/disciplinasDisponiveis.jsp");
                } catch (Exception e) {
                    throw new ServletException("Erro ao listar turmas disponíveis: " + e.getMessage(), e);
                }
                break;

            case "MinhasDisciplinas":
                try {
                    HttpSession session = request.getSession();
                    int alunoId = (int) session.getAttribute("alunoId"); // Obtém o ID do aluno da sessão

                    ArrayList<Turma> minhasDisciplinas = turmaDAO.listarDisciplinasInscritas(alunoId);
                    request.setAttribute("minhasDisciplinas", minhasDisciplinas);

                    rd = request.getRequestDispatcher("/views/aluno/disciplina/disciplinasAluno.jsp");
                } catch (Exception e) {
                    throw new ServletException("Erro ao listar disciplinas do aluno: " + e.getMessage(), e);
                }
                break;

            default:
                response.sendRedirect("/AreaRestrita");
                return;
        }

        if (rd != null) {
            rd.forward(request, response);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        TurmaDAO turmaDAO = new TurmaDAO();

        String acao = request.getParameter("acao");
        if (acao == null) {
            acao = "";
        }

        RequestDispatcher rd = null;

        switch (acao) {
            case "Inscrever":
                // Inscreve o aluno na turma
                try {
                    HttpSession session = request.getSession();
                    int alunoId = (int) session.getAttribute("alunoId"); // Obtém o ID do aluno da sessão
                    String codigoTurma = request.getParameter("codigoTurma");

                    if (codigoTurma == null || codigoTurma.isEmpty()) {
                        throw new Exception("Código da turma não informado.");
                    }

                    boolean sucesso = turmaDAO.inscreverAluno(alunoId, codigoTurma); // Método do DAO
                    if (sucesso) {
                        request.setAttribute("mensagem", "Inscrição realizada com sucesso!");
                        request.setAttribute("tipoMensagem", "success");
                    } else {
                        request.setAttribute("mensagem", "Erro: Não foi possível realizar a inscrição. Verifique se a turma está cheia.");
                        request.setAttribute("tipoMensagem", "error");
                    }
                } catch (Exception e) {
                    request.setAttribute("mensagem", "Erro ao inscrever na turma: " + e.getMessage());
                    request.setAttribute("tipoMensagem", "error");
                }

                try {
                    ArrayList<Turma> listaTurmas = turmaDAO.listaTurmasComStatus();
                    request.setAttribute("listaTurmas", listaTurmas);
                } catch (Exception e) {
                    e.printStackTrace();
                }

                rd = request.getRequestDispatcher("/views/aluno/disciplina/disciplinasDisponiveis.jsp");
                break;

            case "CancelarDisciplina":
                // Cancela a inscrição do aluno na turma
                try {
                    HttpSession session = request.getSession();
                    int alunoId = (int) session.getAttribute("alunoId"); // Obtém o ID do aluno da sessão
                    String codigoTurma = request.getParameter("codigoTurma");

                    if (codigoTurma == null || codigoTurma.isEmpty()) {
                        throw new Exception("Código da turma não informado.");
                    }

                    boolean sucesso = turmaDAO.excluirInscricao(alunoId, codigoTurma); // Método do DAO
                    if (sucesso) {
                        request.setAttribute("mensagem", "Inscrição cancelada com sucesso!");
                        request.setAttribute("tipoMensagem", "success");
                    } else {
                        request.setAttribute("mensagem", "Erro: Não foi possível cancelar a inscrição.");
                        request.setAttribute("tipoMensagem", "error");
                    }
                } catch (Exception e) {
                    request.setAttribute("mensagem", "Erro ao cancelar a inscrição: " + e.getMessage());
                    request.setAttribute("tipoMensagem", "error");
                }

                try {
                    HttpSession session = request.getSession();
                    int alunoId = (int) session.getAttribute("alunoId"); // Obtém o ID do aluno da sessão
                    ArrayList<Turma> minhasDisciplinas = turmaDAO.listarDisciplinasInscritas(alunoId);
                    request.setAttribute("minhasDisciplinas", minhasDisciplinas);
                } catch (Exception e) {
                    e.printStackTrace();
                }

                rd = request.getRequestDispatcher("/views/aluno/disciplina/disciplinasAluno.jsp");
                break;

            default:
                response.sendRedirect("/AreaRestrita");
                return;
        }

        if (rd != null) {
            rd.forward(request, response);
        }
    }
}
