package controller.professor;

import entidade.Turma;
import model.TurmaDAO;

import java.io.IOException;
import java.util.ArrayList;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet(name = "professorController", urlPatterns = {"/professorController"})
public class professorController extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        TurmaDAO turmaDAO = new TurmaDAO();
        
        String acao = request.getParameter("acao");
        if (acao == null) {
            acao = "ListarNotas";
        }

        RequestDispatcher rd = null;
        
        switch (acao) {
            case "ListarNotas":
                // Lista a nota de todos os alunos de turmas sob responsabilidade de um professor
                try {
                    HttpSession session = request.getSession();
                    int professorId = (int) session.getAttribute("professorId"); // Obtém o ID do professor da sessão
                    
                    ArrayList<Turma> listaNotas = turmaDAO.listarNotasPorProfessor(professorId);
                    request.setAttribute("listaNotas", listaNotas);
                    rd = request.getRequestDispatcher("/views/professor/notas/notasAlunos.jsp");
                } catch (Exception e) {
                    throw new ServletException("Erro ao listar notas dos alunos: " + e.getMessage(), e);
                }
                
                // Adiciona o redirecionamento para a view
                if (rd != null) {
                    rd.forward(request, response);
                } else {
                    response.sendError(HttpServletResponse.SC_NOT_FOUND, "Ação não encontrada.");
                }
                break;
                
            case "LancarNotas":
                try {
                    HttpSession session = request.getSession();
                    int professorId = (int) session.getAttribute("professorId"); // Obtém o ID do professor da sessão
                    
                    ArrayList<Turma> listaNotas = turmaDAO.listarNotasPorProfessor(professorId);
                    request.setAttribute("listaNotas", listaNotas);
                    rd = request.getRequestDispatcher("/views/professor/notas/lancarNota.jsp");
                } catch (Exception e) {
                    throw new ServletException("Erro ao listar notas dos alunos: " + e.getMessage(), e);
                }
                
                // Adiciona o redirecionamento para a view
                if (rd != null) {
                    rd.forward(request, response);
                } else {
                    response.sendError(HttpServletResponse.SC_NOT_FOUND, "Ação não encontrada.");
                }
                break;
        }
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        TurmaDAO turmaDAO = new TurmaDAO();

        String acao = request.getParameter("acao");
        if (acao == null) {
            acao = "";
        }

        RequestDispatcher rd = null;

        switch (acao) {
            case "AtualizarNota":
                try {
                    // Obtém os parâmetros da requisição
                    HttpSession session = request.getSession();
                    int professorId = (int) session.getAttribute("professorId"); // Obtém o ID do professor da sessão
                    int alunoId = Integer.parseInt(request.getParameter("alunoId"));
                    String codigoTurma = request.getParameter("codigoTurma");
                    double nota = Double.parseDouble(request.getParameter("nota")); // Nota enviada no formulário
                    System.out.println("AQUI" + nota);
                    // Validação dos parâmetros
                    if (codigoTurma == null || codigoTurma.isEmpty()) {
                        throw new Exception("Código da turma não informado.");
                    }

                    if (nota < 0 || nota > 10) {
                        throw new Exception("A nota deve estar entre 0 e 10.");
                    }
                    
                    // Atualiza a nota do aluno na turma
                    boolean sucesso = turmaDAO.atualizarNota(codigoTurma, alunoId, nota); // Método do DAO
                    if (sucesso) {
                        request.setAttribute("mensagem", "Nota atualizada com sucesso!");
                        request.setAttribute("tipoMensagem", "success");
                    } else {
                        request.setAttribute("mensagem", "Erro: Não foi possível atualizar a nota.");
                        request.setAttribute("tipoMensagem", "error");
                    }
                } catch (Exception e) {
                    request.setAttribute("mensagem", "Erro ao atualizar a nota: " + e.getMessage());
                    request.setAttribute("tipoMensagem", "error");
                }

                // Carrega a lista de notas para exibição na página
                try {
                    HttpSession session = request.getSession();
                    int professorId = (int) session.getAttribute("professorId"); // ID do professor da sessão
                    TurmaDAO turma = new TurmaDAO();
                    ArrayList<Turma> listaNotas = turma.listarNotasPorProfessor(professorId); // Método do DAO
                    request.setAttribute("listaNotas", listaNotas);
                } catch (Exception e) {
                    e.printStackTrace();
                    request.setAttribute("mensagem", "Erro ao carregar a lista de notas: " + e.getMessage());
                    request.setAttribute("tipoMensagem", "error");
                }

                rd = request.getRequestDispatcher("/views/professor/notas/lancarNota.jsp"); // Página de exibição das notas
                break;
        }

        if (rd != null) {
            rd.forward(request, response);
        }
    }
}
    
