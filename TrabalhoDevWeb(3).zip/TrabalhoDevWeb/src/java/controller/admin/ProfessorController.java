package controller.admin;

import entidade.Professor;
import java.io.IOException;
import java.util.ArrayList;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.ProfessorDAO;

@WebServlet(name = "ProfessorController", urlPatterns = {"/ProfessorController"})
public class ProfessorController extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        ProfessorDAO professorDAO = new ProfessorDAO();
        String acao = request.getParameter("acao");
        

        if (acao == null) {
            acao = "Listar";
        }

        switch (acao) {
            case "Listar": {
                ArrayList<Professor> listaProfessores = professorDAO.getAll();
                request.setAttribute("listaProfessores", listaProfessores);

                RequestDispatcher rd = request.getRequestDispatcher("/views/admin/professor/gerenciarProfessor.jsp");
                rd.forward(request, response);
                break;
            }

            case "Excluir": {
                try {
                    int id = Integer.parseInt(request.getParameter("id"));
                    Professor professor = professorDAO.get(id);
                    if (professor != null && professor.getId() != 0) {
                        professorDAO.delete(professor.getId());
                        request.setAttribute("mensagem", "Professor excluído com sucesso!");
                        request.setAttribute("tipoMensagem", "success");
                    } else {
                        request.setAttribute("mensagem", "Erro: Professor não encontrado.");
                        request.setAttribute("tipoMensagem", "error");
                    }
                } catch (Exception e) {
                    System.err.println("Erro ao excluir professor: " + e.getMessage());
                    request.setAttribute("mensagem", "Erro ao excluir professor: " + e.getMessage());
                    request.setAttribute("tipoMensagem", "error");
                }

                ArrayList<Professor> listaAtualizada = professorDAO.getAll();
                request.setAttribute("listaProfessores", listaAtualizada);

                RequestDispatcher rd = request.getRequestDispatcher("/views/admin/professor/gerenciarProfessor.jsp");
                rd.forward(request, response);
                break;
            }

            case "Alterar": {
                try {
                    int id = Integer.parseInt(request.getParameter("id"));

                    Professor professor = professorDAO.get(id);

                    if (professor != null && professor.getId() != 0) {
                        request.setAttribute("professor", professor);
                    } else {
                        request.setAttribute("mensagem", "Professor não encontrado.");
                        request.setAttribute("tipoMensagem", "error");
                    }

                    RequestDispatcher rd = request.getRequestDispatcher("/views/admin/professor/alterarProfessor.jsp");
                    rd.forward(request, response);

                } catch (Exception e) {
                    System.err.println("Erro ao carregar professor: " + e.getMessage());
                    request.setAttribute("mensagem", "Erro ao carregar professor: " + e.getMessage());
                    request.setAttribute("tipoMensagem", "error");

                    RequestDispatcher rd = request.getRequestDispatcher("/views/admin/professor/gerenciarProfessor.jsp");
                    rd.forward(request, response);
                }
                break;
            }

            case "Registrar": {
                RequestDispatcher rd = request.getRequestDispatcher("/views/admin/professor/registrarProfessor.jsp");
                rd.forward(request, response);
                break;
            }

            default:
                response.sendRedirect("AreaRestrita");
                break;
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String acao = request.getParameter("acao");
        ProfessorDAO professorDAO = new ProfessorDAO();

        if (acao == null) {
            acao = "";
        }

        switch (acao) {
            case "Alterar":
                int id = 0;

                try {
                    id = Integer.parseInt(request.getParameter("id"));
                    String nome = request.getParameter("nome");
                    String email = request.getParameter("email");
                    String cpf = request.getParameter("cpf");
                    String senha = request.getParameter("senha");

                    Professor professor = new Professor();
                    professor.setId(id);
                    professor.setNome(nome);
                    professor.setEmail(email);
                    professor.setCpf(cpf);
                    professor.setSenha(senha);

                    boolean existeOutroEmailOuCpf = professorDAO.existeEmailOuCpf(email, cpf, id);

                    if (existeOutroEmailOuCpf) {
                        request.setAttribute("mensagem", "Erro: O e-mail ou CPF já estão cadastrados.");
                        request.setAttribute("tipoMensagem", "error");
                        request.setAttribute("professor", professor);

                        RequestDispatcher rd = request.getRequestDispatcher("/views/admin/professor/alterarProfessor.jsp");
                        rd.forward(request, response);
                    } else {
                        professorDAO.update(professor);

                        request.setAttribute("mensagem", "Professor atualizado com sucesso!");
                        request.setAttribute("tipoMensagem", "success");

                        ArrayList<Professor> listaProfessores = professorDAO.getAll();
                        request.setAttribute("listaProfessores", listaProfessores);

                        RequestDispatcher rd = request.getRequestDispatcher("/views/admin/professor/gerenciarProfessor.jsp");
                        rd.forward(request, response);
                    }

                } catch (Exception e) {
                    e.printStackTrace();

                    request.setAttribute("mensagem", "Erro ao atualizar professor: " + e.getMessage());
                    request.setAttribute("tipoMensagem", "error");

                    try {
                        Professor professorOriginal = professorDAO.get(id);
                        request.setAttribute("professor", professorOriginal);
                    } catch (Exception ex) {
                        ex.printStackTrace();
                        request.setAttribute("mensagem", "Erro crítico ao carregar dados do professor: " + ex.getMessage());
                        request.setAttribute("tipoMensagem", "error");
                    }

                    RequestDispatcher rd = request.getRequestDispatcher("/views/admin/professor/alterarProfessor.jsp");
                    rd.forward(request, response);
                }
                break;
        
            case "Registrar":
                String nomeReg = request.getParameter("nome");
                String emailReg = request.getParameter("email");
                String cpfReg = request.getParameter("cpf");
                String senhaReg = request.getParameter("senha");

                Professor professorReg = new Professor();
                professorReg.setNome(nomeReg);
                professorReg.setEmail(emailReg);
                professorReg.setCpf(cpfReg);
                professorReg.setSenha(senhaReg);

                String mensagemReg;
                String tipoMensagemReg;

                try {
                    if (professorDAO.existeEmailOuCpf(emailReg, cpfReg, 0)) {
                        mensagemReg = "Erro: O e-mail ou CPF já estão cadastrados.";
                        tipoMensagemReg = "error";
                    } else {
                        professorDAO.insert(professorReg);
                        mensagemReg = "Professor registrado com sucesso!";
                        tipoMensagemReg = "success";
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    mensagemReg = "Erro ao registrar o professor: " + e.getMessage();
                    tipoMensagemReg = "error";
                }

                request.setAttribute("mensagem", mensagemReg);
                request.setAttribute("tipoMensagem", tipoMensagemReg);

                RequestDispatcher rdReg = request.getRequestDispatcher("/views/admin/professor/registrarProfessor.jsp");
                rdReg.forward(request, response);
                break;

            default:
                response.sendRedirect("AreaRestrita");
                break;
        }
    }
}
