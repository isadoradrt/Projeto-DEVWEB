package controller.admin;

import entidade.Aluno;
import java.io.IOException;
import java.util.ArrayList;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.AlunoDAO;

@WebServlet(name = "AlunoController", urlPatterns = {"/AlunoController"})

public class AlunoController extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        AlunoDAO alunoDAO = null;
        try {
            alunoDAO = new AlunoDAO();
        } catch (Exception e) {
        }
        String acao = request.getParameter("acao");
 

        switch (acao) {
            case "Listar": {
                ArrayList<Aluno> listaAlunos = alunoDAO.getAll();
                request.setAttribute("listaAlunos", listaAlunos);

                RequestDispatcher rd = request.getRequestDispatcher("/views/admin/aluno/gerenciarAluno.jsp");
                rd.forward(request, response);
                break;
            }

            case "Excluir": {
                try {
                    int id = Integer.parseInt(request.getParameter("id"));
                    Aluno aluno = alunoDAO.get(id); 
                    if (aluno != null && aluno.getId() != 0) {
                        alunoDAO.delete(aluno.getId());
                        request.setAttribute("mensagem", "Aluno excluído com sucesso!");
                        request.setAttribute("tipoMensagem", "success");
                    } else {
                        request.setAttribute("mensagem", "Erro: Aluno não encontrado.");
                        request.setAttribute("tipoMensagem", "error");
                    }
                } catch (Exception e) {
                    System.err.println("Erro ao excluir aluno: " + e.getMessage());
                    request.setAttribute("mensagem", "Erro ao excluir aluno: " + e.getMessage());
                    request.setAttribute("tipoMensagem", "error");
                }

                
                ArrayList<Aluno> listaAtualizada = alunoDAO.getAll();
                request.setAttribute("listaAlunos", listaAtualizada);

                RequestDispatcher rd = request.getRequestDispatcher("/views/admin/aluno/gerenciarAluno.jsp");
                rd.forward(request, response);
                break;
            }

            case "Alterar": {
                try {
                    int id = Integer.parseInt(request.getParameter("id"));

                    Aluno aluno = alunoDAO.get(id);

                    if (aluno != null) {
                        request.setAttribute("aluno", aluno);
                    } else {
                        request.setAttribute("mensagem", "Aluno não encontrado.");
                        request.setAttribute("tipoMensagem", "error");
                    }

                    RequestDispatcher rd = request.getRequestDispatcher("/views/admin/aluno/alterarAluno.jsp");
                    rd.forward(request, response);

                } catch (Exception e) {
                    System.err.println("Erro ao carregar aluno: " + e.getMessage());
                    request.setAttribute("mensagem", "Erro ao carregar aluno: " + e.getMessage());
                    request.setAttribute("tipoMensagem", "error");

                    RequestDispatcher rd = request.getRequestDispatcher("/views/admin/aluno/gerenciarAluno.jsp");
                    rd.forward(request, response);
                }
                break;
            }

            case "Registrar": {
                RequestDispatcher rd = request.getRequestDispatcher("/views/admin/aluno/registrarAluno.jsp");
                rd.forward(request, response);
                break;
            }

            default:
                response.sendRedirect("AreaRestrita");
                break;
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String acao = request.getParameter("acao");
        AlunoDAO alunoDAO = new AlunoDAO();

        switch (acao) {
            case "Alterar":
                int id = 0; 

                try {
                    id = Integer.parseInt(request.getParameter("id"));
                    String nome = request.getParameter("nome");
                    String email = request.getParameter("email");
                    String celular = request.getParameter("celular");
                    String cpf = request.getParameter("cpf");
                    String senha = request.getParameter("senha");
                    String endereco = request.getParameter("endereco");
                    String cidade = request.getParameter("cidade");
                    String bairro = request.getParameter("bairro");
                    String cep = request.getParameter("cep");

                    Aluno aluno = new Aluno();
                    aluno.setId(id);
                    aluno.setNome(nome);
                    aluno.setEmail(email);
                    aluno.setCelular(celular);
                    aluno.setCpf(cpf);
                    aluno.setSenha(senha);
                    aluno.setEndereco(endereco);
                    aluno.setCidade(cidade);
                    aluno.setBairro(bairro);
                    aluno.setCep(cep);

                    
                    boolean existeOutroEmailOuCpf = alunoDAO.existeEmailOuCpf(email, cpf, id);

                    if (existeOutroEmailOuCpf) {
                        
                        request.setAttribute("mensagem", "Erro: O e-mail ou CPF já estão cadastrados.");
                        request.setAttribute("tipoMensagem", "error");
                        request.setAttribute("aluno", aluno); 

                        RequestDispatcher rd = request.getRequestDispatcher("/views/admin/aluno/alterarAluno.jsp");
                        rd.forward(request, response);
                    } else {
                        alunoDAO.update(aluno);

                        
                        request.setAttribute("mensagem", "Aluno atualizado com sucesso!");
                        request.setAttribute("tipoMensagem", "success");

                        ArrayList<Aluno> listaAlunos = alunoDAO.getAll();
                        request.setAttribute("listaAlunos", listaAlunos);

                        RequestDispatcher rd = request.getRequestDispatcher("/views/admin/aluno/gerenciarAluno.jsp");
                        rd.forward(request, response);
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                    request.setAttribute("mensagem", "Erro ao atualizar aluno: " + e.getMessage());
                    request.setAttribute("tipoMensagem", "error");

                    try {
                        Aluno alunoOriginal = alunoDAO.get(id);
                        request.setAttribute("aluno", alunoOriginal);
                    } catch (Exception ex) {
                        e.printStackTrace();
                        request.setAttribute("mensagem", "Erro crítico ao carregar dados do aluno: " + ex.getMessage());
                        request.setAttribute("tipoMensagem", "error");
                    }

                    RequestDispatcher rd = request.getRequestDispatcher("/views/admin/aluno/alterarAluno.jsp");
                    rd.forward(request, response);
                }
                break;

            case "Registrar":
                
                String nomeReg = request.getParameter("nome");
                String emailReg = request.getParameter("email");
                String celularReg = request.getParameter("celular");
                String cpfReg = request.getParameter("cpf");
                String senhaReg = request.getParameter("senha");
                String enderecoReg = request.getParameter("endereco");
                String cidadeReg = request.getParameter("cidade");
                String bairroReg = request.getParameter("bairro");
                String cepReg = request.getParameter("cep");

                Aluno alunoReg = new Aluno();
                alunoReg.setNome(nomeReg);
                alunoReg.setEmail(emailReg);
                alunoReg.setCelular(celularReg);
                alunoReg.setCpf(cpfReg);
                alunoReg.setSenha(senhaReg);
                alunoReg.setEndereco(enderecoReg);
                alunoReg.setCidade(cidadeReg);
                alunoReg.setBairro(bairroReg);
                alunoReg.setCep(cepReg);

                String mensagemReg;
                String tipoMensagemReg;

                try {
                    if (alunoDAO.existeEmailOuCpf(emailReg, cpfReg, 0)) {
                        mensagemReg = "Erro: O e-mail ou CPF já estão cadastrados.";
                        tipoMensagemReg = "error";
                    } else {
                        alunoDAO.insert(alunoReg);
                        mensagemReg = "Aluno registrado com sucesso!";
                        tipoMensagemReg = "success";
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    mensagemReg = "Erro ao registrar o aluno: " + e.getMessage();
                    tipoMensagemReg = "error";
                }

                request.setAttribute("mensagem", mensagemReg);
                request.setAttribute("tipoMensagem", tipoMensagemReg);

                RequestDispatcher rdReg = request.getRequestDispatcher("/views/admin/aluno/registrarAluno.jsp");
                rdReg.forward(request, response);
                break;

            default:
                response.sendRedirect("AreaRestrita");
                break;
        }
    }
}