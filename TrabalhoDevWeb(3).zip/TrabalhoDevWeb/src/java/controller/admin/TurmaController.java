package controller.admin;

import entidade.Turma;
import model.TurmaDAO;
import model.ProfessorDAO;
import model.DisciplinaDAO;
import model.AlunoDAO;

import java.io.IOException;
import java.util.ArrayList;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "TurmaController", urlPatterns = {"/TurmaController"})
public class TurmaController extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        TurmaDAO turmaDAO = new TurmaDAO();
        ProfessorDAO professorDAO = new ProfessorDAO();
        DisciplinaDAO disciplinaDAO = new DisciplinaDAO();
        AlunoDAO alunoDAO = new AlunoDAO();

        String acao = request.getParameter("acao");
        if (acao == null) {
            acao = "Listar";
        }

        RequestDispatcher rd = null;

        switch (acao) {
            case "Listar":
                try {
                    ArrayList<Turma> listaTurmas = turmaDAO.listaTurmasConsolidadas();
                    request.setAttribute("listaTurmas", listaTurmas);
                    rd = request.getRequestDispatcher("/views/admin/turma/gerenciarTurma.jsp");
                } catch (Exception e) {
                    throw new ServletException("Erro ao listar turmas: " + e.getMessage(), e);
                }
                break;

            case "Registrar":
                try {
                    request.setAttribute("listaProfessores", professorDAO.getAll());
                    request.setAttribute("listaDisciplinas", disciplinaDAO.getAll());
                    request.setAttribute("listaAlunos", alunoDAO.getAll());
                    rd = request.getRequestDispatcher("/views/admin/turma/registrarTurma.jsp");
                } catch (Exception e) {
                    throw new ServletException("Erro ao preparar registro de turma: " + e.getMessage(), e);
                }
                break;

            case "Alterar":
                try {
                    String codigoTurma = request.getParameter("codigoTurma");
                    if (codigoTurma == null || codigoTurma.isEmpty()) {
                        throw new Exception("O parâmetro Código da Turma não foi informado.");
                    }

                    ArrayList<Turma> turmaDetalhes = turmaDAO.obterTurmaPorCodigo(codigoTurma);

                    if (turmaDetalhes.isEmpty()) {
                        throw new Exception("Nenhuma turma encontrada com o Código: " + codigoTurma);
                    }

                    Turma turmaPrincipal = turmaDetalhes.get(0);

                    request.setAttribute("turma", turmaPrincipal);
                    request.setAttribute("codigoTurma", codigoTurma);
                    request.setAttribute("listaProfessores", professorDAO.getAll());
                    request.setAttribute("listaDisciplinas", disciplinaDAO.getAll());
                    request.setAttribute("listaAlunos", alunoDAO.getAll());

                    ArrayList<Integer> alunosSelecionados = new ArrayList<>();
                    for (Turma turma : turmaDetalhes) {
                        alunosSelecionados.add(turma.getAlunoId());
                    }
                    request.setAttribute("alunosSelecionados", alunosSelecionados);

                    rd = request.getRequestDispatcher("/views/admin/turma/alterarTurma.jsp");
                } catch (Exception e) {
                    throw new ServletException("Erro ao preparar alteração da turma: " + e.getMessage(), e);
                }
                break;

            case "Excluir":
                try {
                    String codigoTurma = request.getParameter("codigoTurma"); 
                    if (codigoTurma != null && !codigoTurma.isEmpty()) {
                        turmaDAO.excluirPorCodigo(codigoTurma); 
                        request.setAttribute("mensagem", "Turma excluída com sucesso!");
                        request.setAttribute("tipoMensagem", "success");
                    } else {
                        request.setAttribute("mensagem", "Erro: Código da turma não informado.");
                        request.setAttribute("tipoMensagem", "error");
                    }
                } catch (Exception e) {
                    request.setAttribute("mensagem", "Erro ao excluir turma: " + e.getMessage());
                    request.setAttribute("tipoMensagem", "error");
                }

                try {
                    ArrayList<Turma> listaTurmas = turmaDAO.listaTurmasConsolidadas();
                    request.setAttribute("listaTurmas", listaTurmas);
                } catch (Exception e) {
                    e.printStackTrace();
                }

                rd = request.getRequestDispatcher("/views/admin/turma/gerenciarTurma.jsp");
                break;

            default:
                response.sendRedirect("AreaRestrita");
                return;
        }

        if (rd != null) {
            rd.forward(request, response);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        TurmaDAO turmaDAO = new TurmaDAO();
        ProfessorDAO professorDAO = new ProfessorDAO();
        DisciplinaDAO disciplinaDAO = new DisciplinaDAO();
        AlunoDAO alunoDAO = new AlunoDAO();

        String acao = request.getParameter("acao");
        if (acao == null) {
            acao = "";
        }

        RequestDispatcher rd = null;

        switch (acao) {
            case "Registrar":
                try {
                    int professorId = Integer.parseInt(request.getParameter("professorId"));
                    int disciplinaId = Integer.parseInt(request.getParameter("disciplinaId"));
                    String codigoTurma = request.getParameter("codigoTurma");
                    String[] alunoIds = request.getParameterValues("alunos");

                    if (turmaDAO.codigoTurmaJaExiste(codigoTurma)) {
                        request.setAttribute("mensagem", "Erro: Código da turma já existe.");
                        request.setAttribute("tipoMensagem", "error");
                    } else {
                        turmaDAO.inserirEmLote(professorId, disciplinaId, codigoTurma, alunoIds, 0.0);
                        request.setAttribute("mensagem", "Turma registrada com sucesso!");
                        request.setAttribute("tipoMensagem", "success");
                    }

                    request.setAttribute("listaProfessores", professorDAO.getAll());
                    request.setAttribute("listaDisciplinas", disciplinaDAO.getAll());
                    request.setAttribute("listaAlunos", alunoDAO.getAll());
                } catch (Exception e) {
                    request.setAttribute("mensagem", "Erro ao registrar turma: " + e.getMessage());
                    request.setAttribute("tipoMensagem", "error");
                }

                rd = request.getRequestDispatcher("/views/admin/turma/registrarTurma.jsp");
                break;

            case "Alterar":
                try {
                    int professorId = Integer.parseInt(request.getParameter("professorId"));
                    int disciplinaId = Integer.parseInt(request.getParameter("disciplinaId"));
                    String codigoTurma = request.getParameter("codigoTurma");
                    String codigoTurmaAntigo = request.getParameter("codigoTurmaAntigo"); 
                    String[] alunoIds = request.getParameterValues("alunos");

                    if (!codigoTurma.equals(codigoTurmaAntigo) && turmaDAO.codigoTurmaJaExiste(codigoTurma)) {
                        request.setAttribute("mensagem", "Erro: Código da turma já existe.");
                        request.setAttribute("tipoMensagem", "error");

                        Turma turma = new Turma();
                        turma.setCodigoTurma(codigoTurmaAntigo);
                        turma.setProfessorId(professorId);
                        turma.setDisciplinaId(disciplinaId);

                        request.setAttribute("turma", turma);
                        request.setAttribute("codigoTurma", codigoTurmaAntigo);
                        request.setAttribute("listaProfessores", professorDAO.getAll());
                        request.setAttribute("listaDisciplinas", disciplinaDAO.getAll());
                        request.setAttribute("listaAlunos", alunoDAO.getAll());

                        ArrayList<Integer> alunosSelecionados = new ArrayList<>();
                        if (alunoIds != null) {
                            for (String alunoId : alunoIds) {
                                alunosSelecionados.add(Integer.parseInt(alunoId));
                            }
                        }
                        request.setAttribute("alunosSelecionados", alunosSelecionados);

                        rd = request.getRequestDispatcher("/views/admin/turma/alterarTurma.jsp");
                    } else {
                        turmaDAO.excluirPorCodigo(codigoTurmaAntigo); 
                        turmaDAO.inserirEmLote(professorId, disciplinaId, codigoTurma, alunoIds, 0.0);

                        ArrayList<Turma> listaTurmas = turmaDAO.listaTurmasConsolidadas();
                        request.setAttribute("listaTurmas", listaTurmas);

                        request.setAttribute("mensagem", "Turma alterada com sucesso!");
                        request.setAttribute("tipoMensagem", "success");

                        rd = request.getRequestDispatcher("/views/admin/turma/gerenciarTurma.jsp");
                    }
                } catch (Exception e) {
                    request.setAttribute("mensagem", "Erro ao alterar turma: " + e.getMessage());
                    request.setAttribute("tipoMensagem", "error");

                    try {
                        ArrayList<Turma> listaTurmas = turmaDAO.listaTurmasConsolidadas();
                        request.setAttribute("listaTurmas", listaTurmas);
                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }

                    rd = request.getRequestDispatcher("/views/admin/turma/gerenciarTurma.jsp");
                }
                break;

            default:
                rd = request.getRequestDispatcher("/views/admin/turma/gerenciarTurma.jsp");
                break;
        }

        if (rd != null) {
            rd.forward(request, response);
        }
    }
}
