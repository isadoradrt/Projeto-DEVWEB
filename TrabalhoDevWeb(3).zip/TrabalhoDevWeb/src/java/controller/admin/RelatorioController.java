package controller.admin;

import entidade.Relatorio;
import model.RelatorioDAO;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;

@WebServlet(name = "RelatorioController", urlPatterns = {"/RelatorioController"})
public class RelatorioController extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        RelatorioDAO relatorioDAO = new RelatorioDAO();
        String acao = request.getParameter("acao");

        if (acao == null) {
            acao = "ExibirFormulario"; 
        }

        switch (acao) {
            case "ExibirFormulario": {
                try {
                    ArrayList<String> listaCodigosTurma = relatorioDAO.listarCodigosDeTurma();
                    request.setAttribute("listaCodigosTurma", listaCodigosTurma);

                    RequestDispatcher rd = request.getRequestDispatcher("/views/admin/relatorio/gerarRelatorio.jsp");
                    rd.forward(request, response);
                } catch (Exception e) {
                    e.printStackTrace();
                    request.setAttribute("mensagem", "Erro ao carregar formulário: " + e.getMessage());
                    request.setAttribute("tipoMensagem", "error");

                    RequestDispatcher rd = request.getRequestDispatcher("/views/admin/relatorio/gerarRelatorio.jsp");
                    rd.forward(request, response);
                }
                break;
            }

            case "GerarRelatorio": {
                try {
                    String codigoTurma = request.getParameter("codigoTurma");
                    ArrayList<Relatorio> listaRelatorios;

                    if (codigoTurma == null || codigoTurma.isEmpty()) {
                        listaRelatorios = relatorioDAO.gerarRelatorioTurmas();
                    } else {
                        listaRelatorios = relatorioDAO.gerarRelatorioPorTurma(codigoTurma);
                    }

                    ArrayList<String> listaCodigosTurma = relatorioDAO.listarCodigosDeTurma();
                    request.setAttribute("listaCodigosTurma", listaCodigosTurma);

                    request.setAttribute("listaRelatorios", listaRelatorios);
                    request.setAttribute("mensagem", "Relatório gerado com sucesso!");
                    request.setAttribute("tipoMensagem", "success");

                    RequestDispatcher rd = request.getRequestDispatcher("/views/admin/relatorio/gerarRelatorio.jsp");
                    rd.forward(request, response);

                } catch (Exception e) {
                    e.printStackTrace();
                    request.setAttribute("mensagem", "Erro ao gerar relatório: " + e.getMessage());
                    request.setAttribute("tipoMensagem", "error");

                    RequestDispatcher rd = request.getRequestDispatcher("/views/admin/relatorio/gerarRelatorio.jsp");
                    rd.forward(request, response);
                }
                break;
            }

            case "MostrarDisciplinas": {
                RequestDispatcher rd = request.getRequestDispatcher("/views/public/mostrarDisciplinas.jsp");
                rd.forward(request, response);
                break;
            }

            default:
                response.sendRedirect("AreaRestrita");
                break;
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }
}
