package controller.admin;

import entidade.Disciplina;
import java.io.IOException;
import java.util.ArrayList;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.DisciplinaDAO;

@WebServlet(name = "DisciplinaController", urlPatterns = {"/DisciplinaController"})
public class DisciplinaController extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        DisciplinaDAO disciplinaDAO = new DisciplinaDAO();
        String acao = request.getParameter("acao");
     

        if (acao == null) {
            acao = "Listar"; 
        }

        switch (acao) {
            case "Listar": {
                try {
                    ArrayList<Disciplina> listaDisciplinas = disciplinaDAO.getAll();
                    request.setAttribute("listaDisciplinas", listaDisciplinas);
                    RequestDispatcher rd = request.getRequestDispatcher("/views/admin/disciplina/gerenciarDisciplina.jsp");
                    rd.forward(request, response);
                } catch (Exception e) {
                    throw new ServletException("Erro ao listar disciplinas: " + e.getMessage());
                }
                break;
            }

            case "Excluir": {
                try {
                    int id = Integer.parseInt(request.getParameter("id"));
                    Disciplina disciplina = disciplinaDAO.get(id); 
                    if (disciplina != null && disciplina.getId() != 0) {
                        disciplinaDAO.delete(disciplina.getId());
                        request.setAttribute("mensagem", "Disciplina excluída com sucesso!");
                        request.setAttribute("tipoMensagem", "success");
                    } else {
                        request.setAttribute("mensagem", "Erro: Disciplina não encontrada.");
                        request.setAttribute("tipoMensagem", "error");
                    }
                } catch (Exception e) {
                    System.err.println("Erro ao excluir disciplina: " + e.getMessage());
                    request.setAttribute("mensagem", "Erro ao excluir disciplina: " + e.getMessage());
                    request.setAttribute("tipoMensagem", "error");
                }

                try {
                    ArrayList<Disciplina> listaAtualizada = disciplinaDAO.getAll();
                    request.setAttribute("listaDisciplinas", listaAtualizada);
                } catch (Exception e) {
                    System.err.println("Erro ao atualizar lista de disciplinas: " + e.getMessage());
                    request.setAttribute("mensagem", "Erro ao atualizar lista de disciplinas: " + e.getMessage());
                    request.setAttribute("tipoMensagem", "error");
                }

                RequestDispatcher rd = request.getRequestDispatcher("/views/admin/disciplina/gerenciarDisciplina.jsp");
                rd.forward(request, response);
                break;
            }

            case "Alterar": {
                try {
                    int id = Integer.parseInt(request.getParameter("id"));
                    Disciplina disciplina = disciplinaDAO.get(id);

                    if (disciplina != null && disciplina.getId() != 0) {
                        request.setAttribute("disciplina", disciplina);
                    } else {
                        request.setAttribute("mensagem", "Disciplina não encontrada.");
                        request.setAttribute("tipoMensagem", "error");
                    }

                    RequestDispatcher rd = request.getRequestDispatcher("/views/admin/disciplina/alterarDisciplina.jsp");
                    rd.forward(request, response);

                } catch (Exception e) {
                    System.err.println("Erro ao carregar disciplina: " + e.getMessage());
                    request.setAttribute("mensagem", "Erro ao carregar disciplina: " + e.getMessage());
                    request.setAttribute("tipoMensagem", "error");

                    RequestDispatcher rd = request.getRequestDispatcher("/views/admin/disciplina/gerenciarDisciplina.jsp");
                    rd.forward(request, response);
                }
                break;
            }

            case "Registrar": {
                RequestDispatcher rd = request.getRequestDispatcher("/views/admin/disciplina/registrarDisciplina.jsp");
                rd.forward(request, response);
                break;
            }

            default:
                response.sendRedirect("AreaRestrita");
                break;
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String acao = request.getParameter("acao");
        DisciplinaDAO disciplinaDAO = new DisciplinaDAO();

        if (acao == null) {
            acao = "";
        }

        switch (acao) {
            case "Alterar":
                int id = 0; 

                try {
                    id = Integer.parseInt(request.getParameter("id"));
                    String nome = request.getParameter("nome");
                    String requisito = request.getParameter("requisito");
                    String ementa = request.getParameter("ementa");
                    String cargaHorariaStr = request.getParameter("cargaHoraria");
                    Integer cargaHoraria = null; 

                    if (nome == null || nome.trim().isEmpty()) {
                        throw new Exception("Nome da disciplina é obrigatório.");
                    }

                    if (cargaHorariaStr != null && !cargaHorariaStr.trim().isEmpty()) {
                        try {
                            cargaHoraria = Integer.parseInt(cargaHorariaStr);
                            if (cargaHoraria <= 0) {
                                throw new Exception("Carga horária deve ser positiva.");
                            }
                        } catch (NumberFormatException e) {
                            throw new Exception("Carga horária inválida.");
                        }
                    }

                    Disciplina disciplina = new Disciplina();
                    disciplina.setId(id);
                    disciplina.setNome(nome);
                    disciplina.setRequisito(requisito);
                    disciplina.setEmenta(ementa);
                    disciplina.setCargaHoraria(cargaHoraria);

                    boolean existeOutroNome = disciplinaDAO.existeNome(nome, id);

                    if (existeOutroNome) {
                        request.setAttribute("mensagem", "Erro: Já existe uma disciplina com este nome.");
                        request.setAttribute("tipoMensagem", "error");
                        request.setAttribute("disciplina", disciplina); 

                        RequestDispatcher rd = request.getRequestDispatcher("/views/admin/disciplina/alterarDisciplina.jsp");
                        rd.forward(request, response);
                    } else {
                        disciplinaDAO.update(disciplina);

                        request.setAttribute("mensagem", "Disciplina atualizada com sucesso!");
                        request.setAttribute("tipoMensagem", "success");

                        ArrayList<Disciplina> listaDisciplinas = disciplinaDAO.getAll();
                        request.setAttribute("listaDisciplinas", listaDisciplinas);

                        RequestDispatcher rd = request.getRequestDispatcher("/views/admin/disciplina/gerenciarDisciplina.jsp");
                        rd.forward(request, response);
                    }

                } catch (Exception e) {
                    e.printStackTrace();

                    request.setAttribute("mensagem", "Erro ao atualizar disciplina: " + e.getMessage());
                    request.setAttribute("tipoMensagem", "error");

                    try {
                        Disciplina disciplinaOriginal = disciplinaDAO.get(id);
                        request.setAttribute("disciplina", disciplinaOriginal);
                    } catch (Exception ex) {
                        ex.printStackTrace();
                        request.setAttribute("mensagem", "Erro crítico ao carregar dados da disciplina: " + ex.getMessage());
                        request.setAttribute("tipoMensagem", "error");
                    }

                    RequestDispatcher rd = request.getRequestDispatcher("/views/admin/disciplina/alterarDisciplina.jsp");
                    rd.forward(request, response);
                }
                break;

            case "Registrar":
                
                String nomeReg = request.getParameter("nome");
                String requisitoReg = request.getParameter("requisito");
                String ementaReg = request.getParameter("ementa");
                String cargaHorariaRegStr = request.getParameter("cargaHoraria");
                Integer cargaHorariaReg = null; 

                String mensagemReg;
                String tipoMensagemReg;

                try {
                    
                    if (nomeReg == null || nomeReg.trim().isEmpty()) {
                        throw new Exception("Nome da disciplina é obrigatório.");
                    }

                    if (cargaHorariaRegStr != null && !cargaHorariaRegStr.trim().isEmpty()) {
                        try {
                            cargaHorariaReg = Integer.parseInt(cargaHorariaRegStr);
                            if (cargaHorariaReg <= 0) {
                                throw new Exception("Carga horária deve ser positiva.");
                            }
                        } catch (NumberFormatException e) {
                            throw new Exception("Carga horária inválida.");
                        }
                    }
                    
                    if (disciplinaDAO.existeNome(nomeReg, 0)) {
                        mensagemReg = "Erro: Já existe uma disciplina com este nome.";
                        tipoMensagemReg = "error";
                    } else {
                        Disciplina disciplinaReg = new Disciplina(nomeReg, requisitoReg, ementaReg, cargaHorariaReg);
                        disciplinaDAO.insert(disciplinaReg);
                        mensagemReg = "Disciplina registrada com sucesso!";
                        tipoMensagemReg = "success";
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    mensagemReg = "Erro ao registrar a disciplina: " + e.getMessage();
                    tipoMensagemReg = "error";
                }

                request.setAttribute("mensagem", mensagemReg);
                request.setAttribute("tipoMensagem", tipoMensagemReg);

                RequestDispatcher rdReg = request.getRequestDispatcher("/views/admin/disciplina/registrarDisciplina.jsp");
                rdReg.forward(request, response);
                break;

            default:
                response.sendRedirect("AreaRestrita");
                break;
        }
    }
}
