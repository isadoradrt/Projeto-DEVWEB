package controller.admin;

import entidade.Administrador;
import java.io.IOException;
import java.util.ArrayList;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.AdministradorDAO;


@WebServlet(name = "AdministradorController", urlPatterns = {"/AdministradorController"})
public class AdministradorController extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        AdministradorDAO administradorDAO = new AdministradorDAO();
        String acao = request.getParameter("acao");

        switch (acao) {
            case "Listar": {
                ArrayList<Administrador> listaAdministradores = administradorDAO.getAll();
                request.setAttribute("listaAdministradores", listaAdministradores);

                RequestDispatcher rd = request.getRequestDispatcher("/views/admin/administrador/gerenciarAdministrador.jsp");
                rd.forward(request, response);
                break;
            }

            case "Excluir": {
                try {
                    int id = Integer.parseInt(request.getParameter("id"));
                    Administrador administrador = administradorDAO.get(id);
                    if (administrador != null && administrador.getId() != 0) {
                        administradorDAO.delete(administrador.getId());
                        request.setAttribute("mensagem", "Administrador excluído com sucesso!");
                        request.setAttribute("tipoMensagem", "success");
                    } else {
                        request.setAttribute("mensagem", "Erro: Administrador não encontrado.");
                        request.setAttribute("tipoMensagem", "error");
                    }
                } catch (Exception e) {
                    request.setAttribute("mensagem", "Erro ao excluir administrador: " + e.getMessage());
                    request.setAttribute("tipoMensagem", "error");
                }

                ArrayList<Administrador> listaAtualizada = administradorDAO.getAll();
                request.setAttribute("listaAdministradores", listaAtualizada);

                RequestDispatcher rd = request.getRequestDispatcher("/views/admin/administrador/gerenciarAdministrador.jsp");
                rd.forward(request, response);
                break;
            }

            case "Alterar": {
                try {
                    int id = Integer.parseInt(request.getParameter("id"));
                    Administrador administrador = administradorDAO.get(id);
                    if (administrador != null) {
                        request.setAttribute("administrador", administrador);
                    } else {
                        request.setAttribute("mensagem", "Administrador não encontrado.");
                        request.setAttribute("tipoMensagem", "error");
                    }

                    RequestDispatcher rd = request.getRequestDispatcher("/views/admin/administrador/alterarAdministrador.jsp");
                    rd.forward(request, response);
                } catch (Exception e) {
                    request.setAttribute("mensagem", "Erro ao carregar administrador: " + e.getMessage());
                    request.setAttribute("tipoMensagem", "error");

                    RequestDispatcher rd = request.getRequestDispatcher("/views/admin/administrador/gerenciarAdministrador.jsp");
                    rd.forward(request, response);
                }
                break;
            }

            case "Registrar": {
                RequestDispatcher rd = request.getRequestDispatcher("/views/admin/administrador/registrarAdministrador.jsp");
                rd.forward(request, response);
                break;
            }

            default:
                response.sendRedirect("AreaRestrita");
                break;
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String acao = request.getParameter("acao");
        AdministradorDAO administradorDAO = new AdministradorDAO();

        switch (acao) {
            case "Registrar": {
                try {
                    String nome = request.getParameter("nome");
                    String cpf = request.getParameter("cpf");
                    String endereco = request.getParameter("endereco");
                    String senha = request.getParameter("senha");
                    String aprovado = request.getParameter("aprovado");

                    if (administradorDAO.existeCpf(cpf, 0)) {
                        request.setAttribute("mensagem", "Erro: O CPF já está cadastrado.");
                        request.setAttribute("tipoMensagem", "error");
                        RequestDispatcher rd = request.getRequestDispatcher("/views/admin/administrador/registrarAdministrador.jsp");
                        rd.forward(request, response);
                        return;
                    }

                    Administrador administrador = new Administrador(nome, cpf, endereco, senha, aprovado);
                    administradorDAO.insert(administrador);

                    request.setAttribute("mensagem", "Administrador registrado com sucesso!");
                    request.setAttribute("tipoMensagem", "success");
                } catch (Exception e) {
                    request.setAttribute("mensagem", "Erro ao registrar administrador: " + e.getMessage());
                    request.setAttribute("tipoMensagem", "error");
                }
                RequestDispatcher rd = request.getRequestDispatcher("/views/admin/administrador/registrarAdministrador.jsp");
                rd.forward(request, response);
                break;
            }
            case "Alterar": {
                try {
                    int id = Integer.parseInt(request.getParameter("id"));
                    String nome = request.getParameter("nome");
                    String cpf = request.getParameter("cpf");
                    String endereco = request.getParameter("endereco");
                    String senha = request.getParameter("senha");
                    String aprovado = request.getParameter("aprovado");

                    if (administradorDAO.existeCpf(cpf, id)) {
                        request.setAttribute("mensagem", "Erro: O CPF já está cadastrado.");
                        request.setAttribute("tipoMensagem", "error");
                        Administrador administrador = new Administrador(nome, cpf, endereco, senha, aprovado);
                        administrador.setId(id);
                        request.setAttribute("administrador", administrador);

                        RequestDispatcher rd = request.getRequestDispatcher("/views/admin/administrador/alterarAdministrador.jsp");
                        rd.forward(request, response);
                        return;
                    }

                    Administrador administrador = new Administrador(nome, cpf, endereco, senha, aprovado);
                    administrador.setId(id);
                    administradorDAO.update(administrador);

                    request.setAttribute("mensagem", "Administrador atualizado com sucesso!");
                    request.setAttribute("tipoMensagem", "success");

                    // Recarregar a lista de administradores
                    ArrayList<Administrador> listaAdministradores = administradorDAO.getAll();
                    request.setAttribute("listaAdministradores", listaAdministradores);

                    RequestDispatcher rd = request.getRequestDispatcher("/views/admin/administrador/gerenciarAdministrador.jsp");
                    rd.forward(request, response);
                } catch (Exception e) {
                    request.setAttribute("mensagem", "Erro ao atualizar administrador: " + e.getMessage());
                    request.setAttribute("tipoMensagem", "error");

                    RequestDispatcher rd = request.getRequestDispatcher("/views/admin/administrador/alterarAdministrador.jsp");
                    rd.forward(request, response);
                }
                break;
            }

        }
    }
}
