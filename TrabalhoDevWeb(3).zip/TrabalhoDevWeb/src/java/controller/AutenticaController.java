package controller;

import entidade.Administrador;
import entidade.Aluno;
import entidade.Professor;
import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.AdministradorDAO;
import model.AlunoDAO;
import model.ProfessorDAO;

/**
 *
 * @author Leonardo
 */
@WebServlet(name = "AutenticaController", urlPatterns = {"/AutenticaController"})
public class AutenticaController extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        RequestDispatcher rd;
        rd = request.getRequestDispatcher("/views/autenticacao/formLogin.jsp");
        rd.forward(request, response);

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        RequestDispatcher rd;
        HttpSession session = request.getSession();
        String cpf_user = request.getParameter("cpf");
        String senha_user = request.getParameter("senha");

        if (cpf_user.isEmpty() || senha_user.isEmpty()) {
            request.setAttribute("msgError", "Preencha todos os campos!");
            rd = request.getRequestDispatcher("/views/autenticacao/formLogin.jsp");
            rd.forward(request, response);
            return;
        }

        // Tentativa de login como Administrador
        Administrador administradorObtido = null;
        AdministradorDAO administradorDAO = new AdministradorDAO();
        try {
            administradorObtido = administradorDAO.logar(new Administrador(cpf_user, senha_user));
        } catch (Exception ex) {
            System.out.println("Erro ao verificar administrador: " + ex.getMessage());
        }

        if (administradorObtido != null && administradorObtido.getId() != 0) {
            if ("S".equals(administradorObtido.getAprovado())) {
                session.setAttribute("administrador", administradorObtido);
                rd = request.getRequestDispatcher("/admin/dashboard");
                rd.forward(request, response);
            } else {
                request.setAttribute("msgError", "Acesso negado: Administrador não aprovado.");
                rd = request.getRequestDispatcher("/views/autenticacao/formLogin.jsp");
                rd.forward(request, response);
            }
            return;
        }

        // Tentativa de login como Aluno
        Aluno alunoObtido = null;
        AlunoDAO alunoDAO = new AlunoDAO();
        try {
            alunoObtido = alunoDAO.logar(new Aluno(cpf_user, senha_user));
        } catch (Exception ex) {
            System.out.println("Erro ao verificar aluno: " + ex.getMessage());
        }

        if (alunoObtido != null && alunoObtido.getId() != 0) {
            session.setAttribute("aluno", alunoObtido);
            session.setAttribute("alunoId", alunoObtido.getId()); // Armazena explicitamente o ID do aluno
            rd = request.getRequestDispatcher("/views/aluno/dashboard/areaRestrita.jsp");
            rd.forward(request, response);
        }
        
        // Tentativa de login como Professor
        Professor professorObtido = null;
        ProfessorDAO professorDAO = new ProfessorDAO();
        try {
            professorObtido = professorDAO.logar(new Professor(cpf_user, senha_user));
        } catch (Exception ex) {
            System.out.println("Erro ao verificar professor: " + ex.getMessage());
        }

        if (professorObtido != null && professorObtido.getId() != 0) {
            session.setAttribute("professor", professorObtido);
            session.setAttribute("professorId", professorObtido.getId());
            rd = request.getRequestDispatcher("/views/professor/dashboard/areaRestrita.jsp");
            rd.forward(request, response);
            return;
        }
        
        // Login falhou para ambos
        request.setAttribute("msgError", "Usuário e/ou senha incorreto");
        rd = request.getRequestDispatcher("/views/autenticacao/formLogin.jsp");
        rd.forward(request, response); 
    }
}
