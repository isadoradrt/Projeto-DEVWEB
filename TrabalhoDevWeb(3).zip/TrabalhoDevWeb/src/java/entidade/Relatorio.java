package entidade;

public class Relatorio {

    private String codigoTurma;
    private String disciplinaNome;
    private String alunoNome;
    private double nota;

    
    public Relatorio(String codigoTurma, String disciplinaNome, String alunoNome, double nota) {
        this.codigoTurma = codigoTurma;
        this.disciplinaNome = disciplinaNome;
        this.alunoNome = alunoNome;
        this.nota = nota;
    }

  
    public Relatorio(String codigoTurma, String alunoNome, double nota) {
        this.codigoTurma = codigoTurma;
        this.alunoNome = alunoNome;
        this.nota = nota;
        this.disciplinaNome = ""; 
    }

   
    public Relatorio() {
        this.codigoTurma = "";
        this.disciplinaNome = "";
        this.alunoNome = "";
        this.nota = 0.0;
    }

    
    public String getCodigoTurma() {
        return codigoTurma;
    }

    public void setCodigoTurma(String codigoTurma) {
        this.codigoTurma = codigoTurma;
    }

    public String getDisciplinaNome() {
        return disciplinaNome;
    }

    public void setDisciplinaNome(String disciplinaNome) {
        this.disciplinaNome = disciplinaNome;
    }

    public String getAlunoNome() {
        return alunoNome;
    }

    public void setAlunoNome(String alunoNome) {
        this.alunoNome = alunoNome;
    }

    public double getNota() {
        return nota;
    }

    public void setNota(double nota) {
        this.nota = nota;
    }

}
