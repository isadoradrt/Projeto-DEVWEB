package entidade;

public class Turma {

    private int id;
    private int professorId;
    private int disciplinaId; // ID da disciplina
    private int alunoId;
    private String codigoTurma;
    private double nota;

    // Atributos adicionais
    private String disciplinaNome; // Nome da disciplina associada à turma
    private String professorNome;  // Nome do professor associado à turma
    private int numAlunos;         // Número atual de alunos na turma
    private int maxAlunos;         // Capacidade máxima de alunos na turma
    private String status;         // Status da turma (Disponível ou Cheia)
    private String alunoNome;      // Nome do aluno assocuado à turma

    // Novo relacionamento com Disciplina
    private Disciplina disciplina;

    // Construtores
    public Turma(int id, int professorId, int disciplinaId, int alunoId, String codigoTurma, double nota) {
        this.id = id;
        this.professorId = professorId;
        this.disciplinaId = disciplinaId;
        this.alunoId = alunoId;
        this.codigoTurma = codigoTurma;
        this.nota = nota;
    }

    public Turma(int professorId, int disciplinaId, int alunoId, String codigoTurma, double nota) {
        this.professorId = professorId;
        this.disciplinaId = disciplinaId;
        this.alunoId = alunoId;
        this.codigoTurma = codigoTurma;
        this.nota = nota;
    }

    public Turma() {
        this.id = 0;
        this.professorId = 0;
        this.disciplinaId = 0;
        this.alunoId = 0;
        this.codigoTurma = "";
        this.nota = 0.0;
        this.numAlunos = 0;
        this.maxAlunos = 2; // Capacidade máxima padrão
        this.status = "Disponível"; // Status padrão
    }

    // Getters e Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getProfessorId() {
        return professorId;
    }

    public void setProfessorId(int professorId) {
        this.professorId = professorId;
    }

    public int getDisciplinaId() {
        return disciplinaId;
    }

    public void setDisciplinaId(int disciplinaId) {
        this.disciplinaId = disciplinaId;
    }

    public int getAlunoId() {
        return alunoId;
    }

    public void setAlunoId(int alunoId) {
        this.alunoId = alunoId;
    }

    public String getCodigoTurma() {
        return codigoTurma;
    }

    public void setCodigoTurma(String codigoTurma) {
        this.codigoTurma = codigoTurma;
    }

    public double getNota() {
        return nota;
    }

    public void setNota(double nota) {
        this.nota = nota;
    }

    public String getDisciplinaNome() {
        return disciplinaNome;
    }

    public void setDisciplinaNome(String disciplinaNome) {
        this.disciplinaNome = disciplinaNome;
    }

    public String getProfessorNome() {
        return professorNome;
    }

    public void setProfessorNome(String professorNome) {
        this.professorNome = professorNome;
    }
    
    public String getAlunoNome() {
        return alunoNome;
    }
    
    public void setAlunoNome(String alunoNome) {
        this.alunoNome = alunoNome;
    }

    public int getNumAlunos() {
        return numAlunos;
    }

    public void setNumAlunos(int numAlunos) {
        this.numAlunos = numAlunos;
        this.atualizarStatus(); // Atualiza o status automaticamente
    }

    public int getMaxAlunos() {
        return maxAlunos;
    }

    public void setMaxAlunos(int maxAlunos) {
        this.maxAlunos = maxAlunos;
        this.atualizarStatus(); // Atualiza o status automaticamente
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    // Getter e Setter para Disciplina
    public Disciplina getDisciplina() {
        return disciplina;
    }

    public void setDisciplina(Disciplina disciplina) {
        this.disciplina = disciplina;
    }

    // Método auxiliar para calcular o status da turma
    public void atualizarStatus() {
        this.status = (this.numAlunos < this.maxAlunos) ? "Disponível" : "Cheia";
    }
}
